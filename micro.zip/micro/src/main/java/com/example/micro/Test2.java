package com.example.micro;

import java.util.HashMap;
import java.util.Map;

public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub 2,3,5,2,7,2,3 Mary had a little lamb

		
		int [] arr={2,3,5,2,7,2,3};
		HashMap<Integer,Integer> hm= new HashMap<Integer,Integer>();
		
		for (int i=0;i<arr.length;i++){
			if(hm.containsKey(arr[i])){
				hm.put(arr[i], hm.get(arr[i])+1);
			}else{
				hm.put(arr[i], 1);
			}
		}
		for(Map.Entry m: hm.entrySet()){
			System.out.println(m.getKey()+" "+m.getValue());
		}
		
		String str="Mary had a little lamb";
		String [] arr2=str.split(" ");
		StringBuilder sb= new StringBuilder();
		for(int i=arr2.length-1;i<=0;i--){
			sb=sb.append(arr2[i]);
		}
		System.out.println(sb.toString());

	}

}
