package com.example.micro;

public class Test3 extends Test_Static_Overloading{
	
	
	public static void m1(int a){
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="Mary had a little lamb";
		String [] arr2=str.split(" ");
		StringBuilder sb= new StringBuilder();
		for(int i=arr2.length-1;i>=0;i--){
			sb.append(arr2[i]+" ");
		}
		System.out.println(sb.toString());

	}

}
