package com.example.micro;

public class Test_Static_Overloading {
	public static void m1(int a){
		
	}
	public static void m1(int a,int b){
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(10+20+"test");
		System.out.println("test"+10+20);

	}

}


