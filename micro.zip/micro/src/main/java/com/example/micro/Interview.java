package com.example.micro;

import java.util.HashMap;
import java.util.Map;

public class Interview {

	public static void main(String[] args) {
		//System.out.println(m1(1));
		//System.out.println(m1("Hello"));
		//System.out.println(m1(new String ("World")));
		
		String str1="sanjay";
		String str2="sanjay";
		String str3= new String("sanjay");
		if(str1==str2){
			System.out.println("== true");
		}
		if(str1.equals(str2)){
			System.out.println("equals true");
		}
		if(str1==str3){
			System.out.println("new  true");
		}
		if(str1.equals(str3)){
			System.out.println("new equals  true");
		}
		
		HashMap<String,Integer> map= new HashMap<String,Integer>();
		map.put(str1, 1);
		map.put(str2, 2);
		map.put(str3, 3);
		System.out.println(map.get(str1));
		/*for(Map.Entry m:map.entrySet()){
			sys
		}*/
	}
	
	public static String m1(String s) {
		System.out.println("In String");
		return s;
		
	}
	public static Object m1(Object s) {
		System.out.println("In Object");
		return s;
		
	}

}
